﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;

namespace _03.Tuple_First
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] firstLine = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string fullName = firstLine[0] + " " + firstLine[1];
            string address = firstLine[2];

            string[] secondLine = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string name = secondLine[0];
            int litersOfBeer = int.Parse(secondLine[1]);

            string[] thirdLine = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            int intNum = int.Parse(thirdLine[0]);
            double doubleNum = double.Parse(thirdLine[1]);

            Tuple<string, string> nameAndAdress = new Tuple<string, string>(fullName, address);
            Tuple<string, int> nameAndLitersOfBeer = new Tuple<string, int>(name, litersOfBeer);
            Tuple<int, double> intAndDouble = new Tuple<int, double>(intNum, doubleNum);

            Console.WriteLine(
                nameAndAdress.ToString() + "\n" +
                nameAndLitersOfBeer.ToString() + "\n" +
                intAndDouble.ToString());
        }
    }
}
