﻿using System;
using System.Collections.Generic;

namespace _01.GenericBoxOfString
{
    public class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<Box<int>> boxes = new List<Box<int>>();
            for (int i = 0; i < n; i++)
            {
                boxes.Add(new Box<int>(int.Parse(Console.ReadLine())));
            }

            boxes.ForEach(b => Console.WriteLine(b.ToString()));
        }
    }
}
